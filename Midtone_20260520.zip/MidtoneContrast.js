#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FrameStyle.jsh>
#include "PixInsightToolsPreviewControl.jsh"

#feature-icon  midtonethumb.svg
#feature-id    MidtoneMaskContrast : Utilities > Midtone Mask Contrast | Post Editing Scripts > Midtone Mask Contrast
#feature-info  Creates a midtone mask, applies a curves transformation using the mask, \
               then force-closes the mask windows. Rewritten for PixInsight 1.9.4 V8 engine.

#define TITLE   "Mid Tone Contrast"
#define VERSION "0.4"

// =============================================================================
// Global parameters
// =============================================================================

// Declared with var so re-running in the same PI session doesn't throw a
// redeclaration error. The object is fully reinitialised each run inside main().
var MidtoneParameters = {};

function initParameters() {
   MidtoneParameters.applyMidtone     = false;
   MidtoneParameters.lowMidtoneRange  = false;
   MidtoneParameters.highMidtoneRange = false;
   MidtoneParameters.createNewImage   = false;  // false = replace, true = new image
   MidtoneParameters.targetView       = undefined;
   MidtoneParameters.previewControl   = null;
   MidtoneParameters.originalImage    = null;
   MidtoneParameters.previewIsOriginal = true;  // toggle state for before/after
   MidtoneParameters.previewEnabled    = false; // preview checkbox state

   MidtoneParameters.save = function() {
      Parameters.set("applyMidtone",     this.applyMidtone);
      Parameters.set("lowMidtoneRange",  this.lowMidtoneRange);
      Parameters.set("highMidtoneRange", this.highMidtoneRange);
      Parameters.set("createNewImage",   this.createNewImage);
   };

   MidtoneParameters.load = function() {
      if (Parameters.has("applyMidtone"))
         this.applyMidtone = Parameters.getBoolean("applyMidtone");
      if (Parameters.has("lowMidtoneRange"))
         this.lowMidtoneRange = Parameters.getBoolean("lowMidtoneRange");
      if (Parameters.has("highMidtoneRange"))
         this.highMidtoneRange = Parameters.getBoolean("highMidtoneRange");
      if (Parameters.has("createNewImage"))
         this.createNewImage = Parameters.getBoolean("createNewImage");
   };
}

// =============================================================================
// Mask formulas (shared between preview and execution)
// =============================================================================

function maskMid(v) {
   return 0.25 * ((1 / (1 + Math.exp(-5  * (v - 0.25)))) *
                  (1 - (1 / (1 + Math.exp(-5  * (v - 0.75))))));
}

function maskLow(v) {
   return 0.25 * ((1 / (1 + Math.exp(-10 * (v - 0.1)))) *
                  (1 - (1 / (1 + Math.exp(-10 * (v - 0.9))))));
}

function maskHigh(v) {
   return 0.5  * ((1 / (1 + Math.exp(-10 * (v - 0.1)))) *
                  (1 - (1 / (1 + Math.exp(-10 * (v - 0.9))))));
}

// K-curve: piecewise linear approximation of the S-curve used in CurvesTransformation.
// Control points: [0, 0], [0.33075, 0.16279], [0.58656, 0.71576], [1, 1]
function curveK(x) {
   if (x <= 0.33075)
      return (x / 0.33075) * 0.16279;
   if (x <= 0.58656)
      return 0.16279 + ((x - 0.33075) / (0.58656 - 0.33075)) * (0.71576 - 0.16279);
   return 0.71576 + ((x - 0.58656) / (1.0 - 0.58656)) * (1.0 - 0.71576);
}

// =============================================================================
// Helper: find an ImageWindow by its mainView ID
// =============================================================================

function findImageWindowById(winId) {
   const windows = ImageWindow.windows;
   for (let i = 0; i < windows.length; ++i) {
      if (windows[i].mainView.id === winId)
         return windows[i];
   }
   return null;
}

// =============================================================================
// Mask creation via PixelMath
// =============================================================================

function createMaskWindow(view, expression, maskId) {
   const P = new PixelMath;
   P.expression             = expression;
   P.useSingleExpression    = true;
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages   = false;
   P.generateOutput         = true;
   P.singleThreaded         = false;
   P.optimization           = true;
   P.use64BitWorkingImage   = false;
   P.rescale                = false;
   P.truncate               = true;
   P.createNewImage         = true;
   P.showNewImage           = false;
   P.newImageId             = maskId;
   P.newImageColorSpace     = PixelMath.prototype.Gray;
   P.newImageSampleFormat   = PixelMath.prototype.SameAsTarget;
   P.executeOn(view);

   const newWin = findImageWindowById(maskId);
   if (newWin) {
      newWin.show = false;
      const conv = new Convolution;
      conv.mode            = Convolution.prototype.Parametric;
      conv.sigma           = 1.00;
      conv.shape           = 2.00;
      conv.aspectRatio     = 1.00;
      conv.rotationAngle   = 0.00;
      conv.filterSource    = "";
      conv.rescaleHighPass = false;
      conv.executeOn(newWin.mainView);
   }
}

// =============================================================================
// Curves transformation
// =============================================================================

function applyCurvesAdjustment(view) {
   const C = new CurvesTransformation;
   C.R  = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.Rt = CurvesTransformation.prototype.AkimaSubsplines;
   C.G  = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.Gt = CurvesTransformation.prototype.AkimaSubsplines;
   C.B  = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.Bt = CurvesTransformation.prototype.AkimaSubsplines;
   C.K  = [[0.00000, 0.00000], [0.33075, 0.16279], [0.58656, 0.71576], [1.00000, 1.00000]];
   C.Kt = CurvesTransformation.prototype.AkimaSubsplines;
   C.A  = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.At = CurvesTransformation.prototype.AkimaSubsplines;
   C.L  = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.Lt = CurvesTransformation.prototype.AkimaSubsplines;
   C.a  = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.at = CurvesTransformation.prototype.AkimaSubsplines;
   C.b  = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.bt = CurvesTransformation.prototype.AkimaSubsplines;
   C.c  = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.ct = CurvesTransformation.prototype.AkimaSubsplines;
   C.H  = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.Ht = CurvesTransformation.prototype.AkimaSubsplines;
   C.S  = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.St = CurvesTransformation.prototype.AkimaSubsplines;
   C.executeOn(view);
}

// =============================================================================
// Force-close all mask windows
// =============================================================================

function forceCloseMaskWindows() {
   const windows = ImageWindow.windows;
   for (let i = windows.length - 1; i >= 0; --i) {
      const w = windows[i];
      if (w.mainView.id.indexOf("mask") !== -1) {
         if (w.mainView.image)
            w.mainView.image.modified = false;
         try {
            if (typeof w.forceClose === "function")
               w.forceClose();
            else
               w.close(true);
         } catch(e) {
            console.writeln("Error force-closing window '" + w.mainView.id + "': " + e);
         }
      }
   }
}

// =============================================================================
// Main execution
// =============================================================================

function applyMaskAndCurvesToView(view, useMid, useLow, useHigh) {
   const terms = [];
   if (useMid)  terms.push("0.25 * ((1 / (1 + exp(-5  * ($T - 0.25)))) * (1 - (1 / (1 + exp(-5  * ($T - 0.75))))))");
   if (useLow)  terms.push("0.25 * ((1 / (1 + exp(-10 * ($T - 0.1))))  * (1 - (1 / (1 + exp(-10 * ($T - 0.9))))))");
   if (useHigh) terms.push("0.5  * ((1 / (1 + exp(-10 * ($T - 0.1))))  * (1 - (1 / (1 + exp(-10 * ($T - 0.9))))))");

   if (terms.length === 0) return;

   const combinedExpr = terms.length === 1
      ? terms[0]
      : "min(1, " + terms.join(" + ") + ")";

   createMaskWindow(view, combinedExpr, "combined_midtone_mask");

   const targetWin = view.window;
   const maskWin   = findImageWindowById("combined_midtone_mask");

   if (maskWin != null) {
      if (targetWin.isMaskCompatible(maskWin)) {
         targetWin.mask         = maskWin;
         targetWin.maskEnabled  = true;
         targetWin.maskVisible  = false;
         targetWin.maskInverted = false;
         targetWin.maskMode     = 0;
      } else {
         console.writeln("Target window is not mask-compatible with combined_midtone_mask.");
      }
   } else {
      console.writeln("combined_midtone_mask window not found.");
   }

   applyCurvesAdjustment(view);

   targetWin.maskEnabled = false;
   targetWin.maskVisible = false;
   if (maskWin && maskWin.mainView && maskWin.mainView.image)
      maskWin.mainView.image.modified = false;

   forceCloseMaskWindows();
}

// =============================================================================
// Preview: pixel-level combined mask + curves blend (no process instances)
// =============================================================================

function applyCombinedMaskedCurvesToImage(image, useMid, useLow, useHigh) {
   const w = image.width;
   const h = image.height;
   const c = image.numberOfChannels;

   for (let ch = 0; ch < c; ++ch) {
      for (let y = 0; y < h; ++y) {
         for (let x = 0; x < w; ++x) {
            const v = image.sample(x, y, ch);
            let mask = 0;
            if (useMid)  mask += maskMid(v);
            if (useLow)  mask += maskLow(v);
            if (useHigh) mask += maskHigh(v);
            if (mask > 1.0) mask = 1.0;
            const out = (1 - mask) * v + mask * curveK(v);
            image.setSample(out, x, y, ch);
         }
      }
   }
}

// Maximum pixel dimension used for preview computation.
// The image is downscaled to fit within this box before the mask math runs,
// making the preview much faster on large images. Final execution always uses
// the full-resolution image.
var PREVIEW_MAX_SIZE = 1200;

function makePreviewSizedImage(sourceImage) {
   const w = sourceImage.width;
   const h = sourceImage.height;
   const maxDim = Math.max(w, h);
   if (maxDim <= PREVIEW_MAX_SIZE)
      return new Image(sourceImage); // already small enough, just clone

   const scale = PREVIEW_MAX_SIZE / maxDim;
   const img   = new Image(sourceImage);
   img.resample(scale);
   return img;
}

function updatePreview() {
   if (!MidtoneParameters.previewControl || !MidtoneParameters.targetView)
      return;

   // When toggled to original, show a downscaled copy of the original
   if (MidtoneParameters.previewIsOriginal) {
      try {
         const origSmall = makePreviewSizedImage(MidtoneParameters.originalImage);
         MidtoneParameters.previewControl.SetPreview(
            origSmall,
            MidtoneParameters.targetView,
            { width: origSmall.width, height: origSmall.height }
         );
      } catch(e) {
         console.writeln("Error showing original in preview: " + e);
      }
      return;
   }

   try {
      // Downscale for fast mask computation — full-res is only used at execution
      const previewImage = makePreviewSizedImage(MidtoneParameters.originalImage);

      if (!MidtoneParameters.applyMidtone &&
          !MidtoneParameters.lowMidtoneRange &&
          !MidtoneParameters.highMidtoneRange) {
         MidtoneParameters.previewControl.SetPreview(
            previewImage,
            MidtoneParameters.targetView,
            { width: previewImage.width, height: previewImage.height }
         );
         return;
      }

      applyCombinedMaskedCurvesToImage(
         previewImage,
         MidtoneParameters.applyMidtone,
         MidtoneParameters.lowMidtoneRange,
         MidtoneParameters.highMidtoneRange
      );

      MidtoneParameters.previewControl.SetPreview(
         previewImage,
         MidtoneParameters.targetView,
         { width: previewImage.width, height: previewImage.height }
      );
   } catch(e) {
      console.writeln("Error updating preview: " + e);
   }
}

// =============================================================================
// Dialog
// =============================================================================

function MidtoneDialog() {
   this.__base__ = Dialog;
   this.__base__();

   const self = this;

   this.minWidth  = 1300;
   this.minHeight = 900;

   // --- Header ---
   this.headerLabel = new Label(this);
   this.headerLabel.backgroundColor = 0xffDBEDFF;
   this.headerLabel.textColor        = 0xff4b0082;
   this.headerLabel.useRichText      = true;
   this.headerLabel.textAlignment    = TextAlign_Left | TextAlign_VertCenter;
   this.headerLabel.margin           = 4;
   this.headerLabel.text             = "<p><b>" + TITLE + " &mdash; v" + VERSION + "</b></p>";

   // --- Description ---
   this.infoLabel = new Label(this);
   this.infoLabel.frameStyle    = FrameStyle_Box;
   this.infoLabel.margin        = 4;
   this.infoLabel.wordWrapping  = true;
   this.infoLabel.useRichText   = true;
   this.infoLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   this.infoLabel.text =
      "<p><b>Description:</b><br>" +
      "Applies midtone-targeted contrast enhancement to <b>non-linear</b> images " +
      "using a sigmoid luminosity mask and an S-curve. " +
      "Multiple mask ranges are combined additively into a single mask before execution." +
      "<br><br>&copy; Neven Krcmarek 2025</p>";

   // --- View list ---
   this.viewList = new ViewList(this);
   this.viewList.getMainViews();
   this.viewList.onViewSelected = function(view) {
      MidtoneParameters.targetView = view;
      // Reset preview state: always start on Original when switching views
      MidtoneParameters.previewIsOriginal = true;
      MidtoneParameters.previewEnabled    = false;
      self.previewCheckBox.checked        = false;
      self.previewStateLabel.text         = "Original";
      console.writeln("Selected view: " + view.id);
      if (view) {
         try {
            MidtoneParameters.originalImage = new Image(view.image);
            // Show downscaled original immediately in the preview panel
            const origSmall = makePreviewSizedImage(MidtoneParameters.originalImage);
            MidtoneParameters.previewControl.SetPreview(
               origSmall, view,
               { width: origSmall.width, height: origSmall.height }
            );
            MidtoneParameters.previewControl.zoomToFit();
         } catch(e) {
            console.writeln("Error setting preview: " + e);
         }
      }
   };

   // --- Preview control ---
   this.previewControl = new PreviewControl(this);
   this.previewControl.setScaledMinSize(1200, 800);
   MidtoneParameters.previewControl = this.previewControl;

   // Clicking anywhere in the preview panel toggles Original <-> Result,
   // but only when the Preview checkbox is enabled and a view is loaded.
   // We piggyback on the scrollbox viewport's existing onMousePress by
   // storing a reference and calling it after our toggle logic.
   const origViewportMousePress =
      this.previewControl.scrollbox.viewport.onMousePress;
   this.previewControl.scrollbox.viewport.onMousePress = function(
         x, y, button, buttonState, modifiers) {
      // Let the original handler run first (panning, zoom rect, etc.)
      if (typeof origViewportMousePress === "function")
         origViewportMousePress.call(this, x, y, button, buttonState, modifiers);
      // Only toggle on a plain left-click with no modifiers
      if (button === MouseButton_Left && modifiers === 0 &&
            MidtoneParameters.previewEnabled &&
            MidtoneParameters.targetView &&
            MidtoneParameters.originalImage) {
         MidtoneParameters.previewIsOriginal = !MidtoneParameters.previewIsOriginal;
         self.previewStateLabel.text = MidtoneParameters.previewIsOriginal
            ? "Original" : "Result";
         updatePreview();
      }
   };

   // --- Mask checkboxes ---
   this.lowMidtoneCheckBox = new CheckBox(this);
   this.lowMidtoneCheckBox.text    = "Low Midtone Contrast";
   this.lowMidtoneCheckBox.checked = MidtoneParameters.lowMidtoneRange;
   this.lowMidtoneCheckBox.onCheck = function(checked) {
      MidtoneParameters.lowMidtoneRange = checked;
      if (MidtoneParameters.previewEnabled && !MidtoneParameters.previewIsOriginal)
         updatePreview();
   };

   this.applyCheckBox = new CheckBox(this);
   this.applyCheckBox.text    = "Medium Midtone Contrast";
   this.applyCheckBox.checked = MidtoneParameters.applyMidtone;
   this.applyCheckBox.onCheck = function(checked) {
      MidtoneParameters.applyMidtone = checked;
      if (MidtoneParameters.previewEnabled && !MidtoneParameters.previewIsOriginal)
         updatePreview();
   };

   this.highMidtoneCheckBox = new CheckBox(this);
   this.highMidtoneCheckBox.text    = "High Midtone Contrast";
   this.highMidtoneCheckBox.checked = MidtoneParameters.highMidtoneRange;
   this.highMidtoneCheckBox.onCheck = function(checked) {
      MidtoneParameters.highMidtoneRange = checked;
      if (MidtoneParameters.previewEnabled && !MidtoneParameters.previewIsOriginal)
         updatePreview();
   };

   // --- Output mode radio buttons ---
   this.replaceRadio = new RadioButton(this);
   this.replaceRadio.text    = "Replace Image";
   this.replaceRadio.checked = !MidtoneParameters.createNewImage;
   this.replaceRadio.onCheck = function(checked) {
      if (checked) MidtoneParameters.createNewImage = false;
   };

   this.newImageRadio = new RadioButton(this);
   this.newImageRadio.text    = "Create New Image";
   this.newImageRadio.checked = MidtoneParameters.createNewImage;
   this.newImageRadio.onCheck = function(checked) {
      if (checked) MidtoneParameters.createNewImage = true;
   };

   this.outputModeGroup = new GroupBox(this);
   this.outputModeGroup.title = "Output";
   this.outputModeGroup.sizer = new VerticalSizer;
   this.outputModeGroup.sizer.margin  = 6;
   this.outputModeGroup.sizer.spacing = 4;
   this.outputModeGroup.sizer.add(this.replaceRadio);
   this.outputModeGroup.sizer.add(this.newImageRadio);

   // --- Preview checkbox (PI-style: enables live preview in the preview panel) ---
   this.previewCheckBox = new CheckBox(this);
   this.previewCheckBox.text    = "Preview";
   this.previewCheckBox.checked = false; // off by default — user opts in
   this.previewCheckBox.toolTip =
      "Enable live preview. When checked, the preview panel shows the processed result. " +
      "Click the preview image to toggle between Original and Result.";
   this.previewCheckBox.onCheck = function(checked) {
      MidtoneParameters.previewEnabled = checked;
      if (checked) {
         // Switch to result view when enabling
         MidtoneParameters.previewIsOriginal = false;
         self.previewStateLabel.text = "Result";
         updatePreview();
      } else {
         // Switch back to original when disabling
         MidtoneParameters.previewIsOriginal = true;
         self.previewStateLabel.text = "Original";
         updatePreview();
      }
   };

   // Small label showing current preview state: "Original" or "Result"
   this.previewStateLabel = new Label(this);
   this.previewStateLabel.text      = "Original";
   this.previewStateLabel.textColor = 0xff606060;
   this.previewStateLabel.toolTip   = "Click the preview image to toggle Original ↔ Result";

   this.previewBarSizer = new HorizontalSizer;
   this.previewBarSizer.spacing = 8;
   this.previewBarSizer.add(this.previewCheckBox);
   this.previewBarSizer.add(this.previewStateLabel);
   this.previewBarSizer.addStretch();

   this.previewGroup = new GroupBox(this);
   this.previewGroup.title = "Before / After";
   this.previewGroup.sizer = new VerticalSizer;
   this.previewGroup.sizer.margin  = 6;
   this.previewGroup.sizer.spacing = 4;
   this.previewGroup.sizer.add(this.previewBarSizer);

   // --- Execute / New Instance buttons ---
   this.execButton = new PushButton(this);
   this.execButton.text    = "Execute";
   this.execButton.onClick = function() { self.ok(); };

   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.onMousePress = function() {
      MidtoneParameters.save();
      self.newInstance();
   };

   this.buttonRow = new HorizontalSizer;
   this.buttonRow.spacing = 8;
   this.buttonRow.add(this.newInstanceButton);
   this.buttonRow.addStretch();
   this.buttonRow.add(this.execButton);

   // --- Checkbox rows ---
   const lowRow = new HorizontalSizer;
   lowRow.add(this.lowMidtoneCheckBox);
   lowRow.addStretch();

   const medRow = new HorizontalSizer;
   medRow.add(this.applyCheckBox);
   medRow.addStretch();

   const highRow = new HorizontalSizer;
   highRow.add(this.highMidtoneCheckBox);
   highRow.addStretch();

   // --- Controls column ---
   this.controlsSizer = new VerticalSizer;
   this.controlsSizer.add(this.headerLabel);
   this.controlsSizer.addSpacing(5);
   this.controlsSizer.add(this.infoLabel);
   this.controlsSizer.addSpacing(15);
   this.controlsSizer.add(this.viewList);
   this.controlsSizer.addSpacing(15);
   this.controlsSizer.add(lowRow);
   this.controlsSizer.addSpacing(10);
   this.controlsSizer.add(medRow);
   this.controlsSizer.addSpacing(10);
   this.controlsSizer.add(highRow);
   this.controlsSizer.addSpacing(15);
   this.controlsSizer.add(this.outputModeGroup);
   this.controlsSizer.addSpacing(15);
   this.controlsSizer.add(this.previewGroup);
   this.controlsSizer.addSpacing(10);
   this.controlsSizer.add(this.buttonRow);
   this.controlsSizer.addStretch();

   // --- Main layout ---
   this.mainSizer = new HorizontalSizer;
   this.mainSizer.margin  = 8;
   this.mainSizer.spacing = 10;
   this.mainSizer.add(this.controlsSizer);
   this.mainSizer.add(this.previewControl);

   this.sizer = new VerticalSizer;
   this.sizer.margin  = 8;
   this.sizer.spacing = 10;
   this.sizer.add(this.mainSizer);

   this.windowTitle = TITLE;
   this.adjustToContents();
}

MidtoneDialog.prototype = new Dialog;

// =============================================================================
// Main entry point
// =============================================================================

function main() {
   initParameters(); // reset state cleanly on every run

   if (Parameters.isViewTarget) {
      MidtoneParameters.load();
      if (!MidtoneParameters.applyMidtone &&
          !MidtoneParameters.lowMidtoneRange &&
          !MidtoneParameters.highMidtoneRange)
         return;
      applyMaskAndCurvesToView(
         Parameters.targetView,
         MidtoneParameters.applyMidtone,
         MidtoneParameters.lowMidtoneRange,
         MidtoneParameters.highMidtoneRange
      );
      return;
   }

   if (Parameters.isGlobalTarget)
      MidtoneParameters.load();

   const dialog = new MidtoneDialog;
   if (dialog.execute() !== 1)
      return;

   if (!MidtoneParameters.targetView) {
      console.writeln("No target view selected. Nothing to do.");
      return;
   }

   if (!MidtoneParameters.applyMidtone &&
       !MidtoneParameters.lowMidtoneRange &&
       !MidtoneParameters.highMidtoneRange) {
      console.writeln("No options selected. Nothing to do.");
      return;
   }

   if (MidtoneParameters.createNewImage) {
      // Clone the target into a new ImageWindow, apply everything to the clone
      const srcView = MidtoneParameters.targetView;
      const newId   = srcView.id + "_midtone";
      const srcImg  = srcView.image;

      const newWin = new ImageWindow(
         srcImg.width,
         srcImg.height,
         srcImg.numberOfChannels,
         srcImg.bitsPerSample,
         srcImg.isReal,
         srcImg.isColor,
         newId
      );
      newWin.mainView.beginProcess();
      newWin.mainView.image.assign(srcImg);
      newWin.mainView.endProcess();

      // Copy keywords and ICC profile from source
      newWin.keywords = srcView.window.keywords;
      if (srcView.window.iccProfile)
         newWin.iccProfile = srcView.window.iccProfile;

      newWin.show();

      applyMaskAndCurvesToView(
         newWin.mainView,
         MidtoneParameters.applyMidtone,
         MidtoneParameters.lowMidtoneRange,
         MidtoneParameters.highMidtoneRange
      );

      console.writeln("New image created: " + newId);
   } else {
      // Replace: apply directly to the selected view
      applyMaskAndCurvesToView(
         MidtoneParameters.targetView,
         MidtoneParameters.applyMidtone,
         MidtoneParameters.lowMidtoneRange,
         MidtoneParameters.highMidtoneRange
      );
   }
}

main();
