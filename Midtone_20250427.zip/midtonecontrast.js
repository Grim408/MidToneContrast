#include <pjsr/Sizer.jsh> 
#include <pjsr/NumericControl.jsh>
#include <pjsr/FrameStyle.jsh>
#include "PixInsightToolsPreviewControl.jsh"

// Define UndoFlag_NoSwapFile if not already defined
if (typeof UndoFlag_NoSwapFile === 'undefined')
   var UndoFlag_NoSwapFile = 0x02;

#feature-icon  midtonethumb.svg
#feature-id    MidtoneMaskContrast : Utilities > Midtone Mask Contrast | Post Editing Scripts > Midtone Mask Contrast
#feature-info Creates a midtone mask, applies a curves transformation using the mask, then force-closes the mask windows using forceClose()

#define TITLE "Mid Tone Contrast" 
#define VERSION "0.2"

// Global parameters.
var MidtoneParameters = {
   applyMidtone: false, // Medium
   lowMidtoneRange: false, // Low
   highMidtoneRange: false, // High
   targetView: undefined,
   previewControl: null,
   originalImage: null, // Store the original image

   save: function() {
      Parameters.set("applyMidtone", this.applyMidtone);
      Parameters.set("lowMidtoneRange", this.lowMidtoneRange);
      Parameters.set("highMidtoneRange", this.highMidtoneRange);
   },

   load: function() {
      if (Parameters.has("applyMidtone"))
         this.applyMidtone = Parameters.getBoolean("applyMidtone");
      if (Parameters.has("lowMidtoneRange"))
         this.lowMidtoneRange = Parameters.getBoolean("lowMidtoneRange");
      if (Parameters.has("highMidtoneRange"))
         this.highMidtoneRange = Parameters.getBoolean("highMidtoneRange");
   }
};

// Helper: Iterate over ImageWindow.windows and return the window whose mainView.id matches winId.
function findImageWindowById(winId) {
   for (var i = 0; i < ImageWindow.windows.length; i++) {
      if (ImageWindow.windows[i].mainView.id === winId)
         return ImageWindow.windows[i];
   }
   return null;
}

// --- Mask Creation Functions ---
function applyMidtoneMask(view) {
   var P = new PixelMath;
   P.expression = "0.25 * ((1 / (1 + exp(-5 * ($T - 0.25)))) * (1 - (1 / (1 + exp(-5 * ($T - 0.75))))))";
   P.useSingleExpression = true;
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages = false;
   P.generateOutput = true;
   P.singleThreaded = false;
   P.optimization = true;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.truncate = true;
   P.createNewImage = true;
   P.showNewImage = false;
   P.newImageId = "midtone_mask";
   P.newImageColorSpace = PixelMath.prototype.Gray;
   P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
   P.executeOn(view);
   
   var newWin = findImageWindowById("midtone_mask");
   if (newWin) {
      newWin.show = false;
      var conv = new Convolution;
      conv.mode = Convolution.prototype.Parametric;
      conv.sigma = 1.00;
      conv.shape = 2.00;
      conv.aspectRatio = 1.00;
      conv.rotationAngle = 0.00;
      conv.filterSource = "";
      conv.rescaleHighPass = false;
      conv.executeOn(newWin.mainView);
   }
}

function applyLowMidtoneMask(view) {
   var P = new PixelMath;
   P.expression = "0.25 * ((1 / (1 + exp(-10 * ($T - 0.1)))) * (1 - (1 / (1 + exp(-10 * ($T - 0.9))))))";
   P.useSingleExpression = true;
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages = false;
   P.generateOutput = true;
   P.singleThreaded = false;
   P.optimization = true;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.truncate = true;
   P.createNewImage = true;
   P.showNewImage = false;
   P.newImageId = "low_midtone_mask";
   P.newImageColorSpace = PixelMath.prototype.Gray;
   P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
   P.executeOn(view);
   
   var newWin = findImageWindowById("low_midtone_mask");
   if (newWin) {
      newWin.show = false;
      var conv = new Convolution;
      conv.mode = Convolution.prototype.Parametric;
      conv.sigma = 1.00;
      conv.shape = 2.00;
      conv.aspectRatio = 1.00;
      conv.rotationAngle = 0.00;
      conv.filterSource = "";
      conv.rescaleHighPass = false;
      conv.executeOn(newWin.mainView);
   }
}

function applyHighMidtoneMask(view) {
   var P = new PixelMath;
   P.expression = "0.5 * ((1 / (1 + exp(-10 * ($T - 0.1)))) * (1 - (1 / (1 + exp(-10 * ($T - 0.9))))))";
   P.useSingleExpression = true;
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages = false;
   P.generateOutput = true;
   P.singleThreaded = false;
   P.optimization = true;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.truncate = true;
   P.createNewImage = true;
   P.showNewImage = false;
   P.newImageId = "high_midtone_mask";
   P.newImageColorSpace = PixelMath.prototype.Gray;
   P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
   P.executeOn(view);
   
   var newWin = findImageWindowById("high_midtone_mask");
   if (newWin) {
      newWin.show = false;
      var conv = new Convolution;
      conv.mode = Convolution.prototype.Parametric;
      conv.sigma = 1.00;
      conv.shape = 2.00;
      conv.aspectRatio = 1.00;
      conv.rotationAngle = 0.00;
      conv.filterSource = "";
      conv.rescaleHighPass = false;
      conv.executeOn(newWin.mainView);
   }
}

// --- Mask Application ---
function applyMaskToView(maskId, targetView) {
   var targetWin = targetView.window;
   var maskWin = findImageWindowById(maskId);
   if (maskWin != null) {
      if (targetWin.isMaskCompatible(maskWin)) {
         targetWin.mask = maskWin;
         targetWin.maskEnabled = true;
         targetWin.maskVisible = true;
         targetWin.maskInverted = false;
         targetWin.maskMode = 0; // default red visualization
      }
      else {
         Console.writeln("Target window is not mask compatible with " + maskId);
      }
   }
   else {
      Console.writeln("Mask window " + maskId + " not found.");
   }
}

// --- Curves Adjustment ---
function applyCurvesAdjustment(targetView) {
   var C = new CurvesTransformation;
   C.R = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.Rt = CurvesTransformation.prototype.AkimaSubsplines;
   C.G = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.Gt = CurvesTransformation.prototype.AkimaSubsplines;
   C.B = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.Bt = CurvesTransformation.prototype.AkimaSubsplines;
   C.K = [[0.00000, 0.00000], [0.33075, 0.16279], [0.58656, 0.71576], [1.00000, 1.00000]];
   C.Kt = CurvesTransformation.prototype.AkimaSubsplines;
   C.A = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.At = CurvesTransformation.prototype.AkimaSubsplines;
   C.L = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.Lt = CurvesTransformation.prototype.AkimaSubsplines;
   C.a = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.at = CurvesTransformation.prototype.AkimaSubsplines;
   C.b = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.bt = CurvesTransformation.prototype.AkimaSubsplines;
   C.c = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.ct = CurvesTransformation.prototype.AkimaSubsplines;
   C.H = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.Ht = CurvesTransformation.prototype.AkimaSubsplines;
   C.S = [[0.00000, 0.00000], [1.00000, 1.00000]];
   C.St = CurvesTransformation.prototype.AkimaSubsplines;
   C.executeOn(targetView);
}

// --- Force Close Mask Windows Using forceClose() ---
function forceCloseMaskWindows() {
   for (var i = ImageWindow.windows.length - 1; i >= 0; i--) {
      var w = ImageWindow.windows[i];
      if (w.mainView.id.indexOf("mask") !== -1) {
         if (w.mainView.image)
            w.mainView.image.modified = false;
         try {
            if (typeof w.forceClose === "function")
               w.forceClose();
            else
               w.close(true);
         }
         catch(e) {
            Console.writeln("Error force closing window " + w.mainView.id + ": " + e);
         }
      }
   }
}

// --- Preview Functions ---
function updatePreview() {
   if (MidtoneParameters.previewControl && MidtoneParameters.targetView) {
      try {
         // Use original image size for preview
         var previewImage = new Image(MidtoneParameters.originalImage);

         if (!MidtoneParameters.applyMidtone &&
             !MidtoneParameters.lowMidtoneRange &&
             !MidtoneParameters.highMidtoneRange) {
            MidtoneParameters.previewControl.SetPreview(previewImage, MidtoneParameters.targetView, {
               width: previewImage.width,
               height: previewImage.height
            });
            return;
         }
         // Combine selected masks for preview
         applyCombinedMaskedCurvesToImage(
            previewImage,
            MidtoneParameters.applyMidtone,
            MidtoneParameters.lowMidtoneRange,
            MidtoneParameters.highMidtoneRange
         );
         MidtoneParameters.previewControl.SetPreview(previewImage, MidtoneParameters.targetView, {
            width: previewImage.width,
            height: previewImage.height
         });
      } catch (e) {
         Console.writeln("Error updating preview: " + e);
      }
   }
}

function applyMaskedCurvesToImage(image, maskType) {
   // K curve: [[0.00000, 0.00000], [0.33075, 0.16279], [0.58656, 0.71576], [1.00000, 1.00000]]
   function curveK(x) {
      if (x <= 0.33075)
         return (x / 0.33075) * 0.16279;
      else if (x <= 0.58656)
         return 0.16279 + ((x - 0.33075) / (0.58656 - 0.33075)) * (0.71576 - 0.16279);
      else
         return 0.71576 + ((x - 0.58656) / (1.0 - 0.58656)) * (1.0 - 0.71576);
   }
   // Mask formulas
   function maskValue(v) {
      if (maskType === 'midtone')
         return 0.25 * ((1 / (1 + Math.exp(-5 * (v - 0.25)))) * (1 - (1 / (1 + Math.exp(-5 * (v - 0.75))))));
      if (maskType === 'low')
         return 0.25 * ((1 / (1 + Math.exp(-10 * (v - 0.1)))) * (1 - (1 / (1 + Math.exp(-10 * (v - 0.9))))));
      if (maskType === 'high')
         return 0.5 * ((1 / (1 + Math.exp(-10 * (v - 0.1)))) * (1 - (1 / (1 + Math.exp(-10 * (v - 0.9))))));
      return 0;
   }
   for (var c = 0; c < image.numberOfChannels; ++c) {
      for (var y = 0; y < image.height; ++y) {
         for (var x = 0; x < image.width; ++x) {
            var v = image.sample(x, y, c);
            var mask = maskValue(v);
            var vCurve = curveK(v);
            var out = (1 - mask) * v + mask * vCurve;
            image.setSample(out, x, y, c);
         }
      }
   }
}

function applyCombinedMaskedCurvesToImage(image, useMid, useLow, useHigh) {
   // For each pixel, combine the masks (additively, capped at 1.0), then blend with the curves
   function curveK(x) {
      if (x <= 0.33075)
         return (x / 0.33075) * 0.16279;
      else if (x <= 0.58656)
         return 0.16279 + ((x - 0.33075) / (0.58656 - 0.33075)) * (0.71576 - 0.16279);
      else
         return 0.71576 + ((x - 0.58656) / (1.0 - 0.58656)) * (1.0 - 0.71576);
   }
   function maskMid(v) {
      return 0.25 * ((1 / (1 + Math.exp(-5 * (v - 0.25)))) * (1 - (1 / (1 + Math.exp(-5 * (v - 0.75))))));
   }
   function maskLow(v) {
      return 0.25 * ((1 / (1 + Math.exp(-10 * (v - 0.1)))) * (1 - (1 / (1 + Math.exp(-10 * (v - 0.9))))));
   }
   function maskHigh(v) {
      return 0.5 * ((1 / (1 + Math.exp(-10 * (v - 0.1)))) * (1 - (1 / (1 + Math.exp(-10 * (v - 0.9))))));
   }
   for (var c = 0; c < image.numberOfChannels; ++c) {
      for (var y = 0; y < image.height; ++y) {
         for (var x = 0; x < image.width; ++x) {
            var v = image.sample(x, y, c);
            var mask = 0;
            if (useMid) mask += maskMid(v);
            if (useLow) mask += maskLow(v);
            if (useHigh) mask += maskHigh(v);
            if (mask > 1.0) mask = 1.0;
            var vCurve = curveK(v);
            var out = (1 - mask) * v + mask * vCurve;
            image.setSample(out, x, y, c);
         }
      }
   }
}

// --- Dialog ---
function MidtoneDialog() {
   this.__base__ = Dialog;
   this.__base__();

   var self = this;
   this.minWidth = 1300;
   this.minHeight = 900;

   // Header
   this.headerLabel = new Label(this);
   this.headerLabel.backgroundColor = 0xffDBEDFF;
   this.headerLabel.textColor = 0xff4b0082;
   this.headerLabel.useRichText = true;
   this.headerLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   this.headerLabel.margin = 4;
   this.headerLabel.text = "<p><b>" + TITLE + " - Ver " + VERSION + "</b></p>";

   // Information
   this.infoLabel = new Label(this);
   this.infoLabel.frameStyle = FrameStyle_Box;
   this.infoLabel.margin = 4;
   this.infoLabel.wordWrapping = true;
   this.infoLabel.useRichText = true;
   this.infoLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   this.infoLabel.text = "<p><b>Description:</b><br>" +
                         "This is a script for making better contrast on <b>non-linear</b> images." +
                         "<br><br>&copy; Neven Krcmarek 2025</p>";

   // View list
   this.viewList = new ViewList(this);
   this.viewList.getMainViews();
   this.viewList.onViewSelected = function(view) {
      MidtoneParameters.targetView = view;
      Console.writeln("Selected view: " + view.id);
      if (view) {
         try {
            // Store the original image
            MidtoneParameters.originalImage = new Image(view.image);
            
            // Set the preview with the original image
            MidtoneParameters.previewControl.SetPreview(view.image, view, {
               width: view.image.width,
               height: view.image.height
            });
            
            // Fit the entire image in the preview window
            MidtoneParameters.previewControl.zoomToFit();
         } catch (e) {
            Console.writeln("Error setting preview: " + e);
         }
      }
   };

   // Preview control
   this.previewControl = new PreviewControl(this);
   this.previewControl.setScaledMinSize(1200, 800);
   MidtoneParameters.previewControl = this.previewControl;

   // Checkboxes for midtone options
   this.lowMidtoneCheckBox = new CheckBox(this);
   this.lowMidtoneCheckBox.text = "Low Midtone Contrast";
   this.lowMidtoneCheckBox.checked = MidtoneParameters.lowMidtoneRange;
   this.lowMidtoneCheckBox.onCheck = function(checked) {
      MidtoneParameters.lowMidtoneRange = checked;
      updatePreview();
   };

   this.applyCheckBox = new CheckBox(this);
   this.applyCheckBox.text = "Medium Midtone Contrast";
   this.applyCheckBox.checked = MidtoneParameters.applyMidtone;
   this.applyCheckBox.onCheck = function(checked) {
      MidtoneParameters.applyMidtone = checked;
      updatePreview();
   };

   this.highMidtoneCheckBox = new CheckBox(this);
   this.highMidtoneCheckBox.text = "High Midtone Contrast";
   this.highMidtoneCheckBox.checked = MidtoneParameters.highMidtoneRange;
   this.highMidtoneCheckBox.onCheck = function(checked) {
      MidtoneParameters.highMidtoneRange = checked;
      updatePreview();
   };

   this.execButton = new PushButton(this);
   this.execButton.text = "Execute";
   this.execButton.width = 40;
   this.execButton.onClick = function() { self.ok(); };

   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.onMousePress = function() {
      MidtoneParameters.save();
      self.newInstance();
   };

   this.buttonRow = new HorizontalSizer;
   this.buttonRow.spacing = 8;
   this.buttonRow.add(this.newInstanceButton);
   this.buttonRow.addStretch();
   this.buttonRow.add(this.execButton);

   // Create horizontal sizers for each checkbox with 30px right spacing
   var lowRow = new HorizontalSizer;
   lowRow.add(this.lowMidtoneCheckBox);
   lowRow.addSpacing(30);

   var medRow = new HorizontalSizer;
   medRow.add(this.applyCheckBox);
   medRow.addSpacing(30);

   var highRow = new HorizontalSizer;
   highRow.add(this.highMidtoneCheckBox);
   highRow.addSpacing(30);

   // Create a vertical sizer for controls
   this.controlsSizer = new VerticalSizer;
   this.controlsSizer.add(this.headerLabel);
   this.controlsSizer.addSpacing(5);
   this.controlsSizer.add(this.infoLabel);
   this.controlsSizer.addSpacing(15);
   this.controlsSizer.add(this.viewList);
   this.controlsSizer.addSpacing(15);
   this.controlsSizer.add(lowRow);
   this.controlsSizer.addSpacing(15);
   this.controlsSizer.add(medRow);
   this.controlsSizer.addSpacing(15);
   this.controlsSizer.add(highRow);
   this.controlsSizer.addSpacing(15);
   this.controlsSizer.add(this.buttonRow);
   this.controlsSizer.addStretch();

   // Create a horizontal sizer for the main layout
   this.mainSizer = new HorizontalSizer;
   this.mainSizer.margin = 8;
   this.mainSizer.add(this.controlsSizer);
   this.mainSizer.addSpacing(10);
   this.mainSizer.add(this.previewControl);

   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.add(this.mainSizer);
   this.sizer.addSpacing(10);

   this.windowTitle = "Midtone Contrast Script";
   this.adjustToContents();
}

MidtoneDialog.prototype = new Dialog;

function showDialog() {
   var dialog = new MidtoneDialog;
   return dialog.execute();
}

// --- Main ---
function main() {
   if (Parameters.isViewTarget) {
      MidtoneParameters.load();
      if (MidtoneParameters.previewControl) {
         updatePreview();
      }
      if (!MidtoneParameters.applyMidtone &&
          !MidtoneParameters.lowMidtoneRange &&
          !MidtoneParameters.highMidtoneRange) return;
      applyMaskAndCurvesToView(
         MidtoneParameters.targetView,
         MidtoneParameters.applyMidtone,
         MidtoneParameters.lowMidtoneRange,
         MidtoneParameters.highMidtoneRange
      );
      forceCloseMaskWindows();
      return;
   }
   else if (Parameters.isGlobalTarget) {
      MidtoneParameters.load();
   }
   var retVal = showDialog();
   if (retVal == 1) {
      if (!MidtoneParameters.applyMidtone &&
          !MidtoneParameters.lowMidtoneRange &&
          !MidtoneParameters.highMidtoneRange) {
         Console.writeln("No options selected. Nothing to do.");
         return;
      }
      applyMaskAndCurvesToView(
         MidtoneParameters.targetView,
         MidtoneParameters.applyMidtone,
         MidtoneParameters.lowMidtoneRange,
         MidtoneParameters.highMidtoneRange
      );
      forceCloseMaskWindows();
   }
}

// --- Mask and Curves for Main Image ---
function applyMaskAndCurvesToView(view, useMid, useLow, useHigh) {
   if (useMid) {
      applyMidtoneMask(view);
      applyMaskToView("midtone_mask", view);
   }
   if (useLow) {
      applyLowMidtoneMask(view);
      applyMaskToView("low_midtone_mask", view);
   }
   if (useHigh) {
      applyHighMidtoneMask(view);
      applyMaskToView("high_midtone_mask", view);
   }
   applyCurvesAdjustment(view);
}

main();
